Opengl/GLUT Installation Instructions

The files in /lib should be placed in        \Program Files\Microsoft Visual Studio\VC98\Lib
The files in /include should be placed in    \Program Files\Microsoft Visual Studio\VC98\Include
The files in /dlls should be placed in       \Windows\System

GLUT library specification can be found in GLUT.spec.ps